# Terms of Service

## 1. Introduction

By using the "Phở Bò" bot (hereinafter referred to as the "Bot"), you agree to comply with these Terms of Service (hereinafter referred to as the "Terms"). If you do not agree with any part of these Terms, you are prohibited from using the Bot.

## 2. Usage Rights

You are granted a non-exclusive, non-transferable, revocable license to use the Bot on your Discord server, provided you comply with these Terms and all applicable laws.

## 3. Terms of Use

- Intentional command spam or attempts to crash the bot should not be made.
- Players only respond to the game's purpose in the game channel, do not take advantage of the game to intentionally say words that do not meet community standards or words that insult or offend others.
- PhoBo Team reserves the rights to prohibit any server or user from using the Bot.
- The client is responsible for any violation caused by them.
- We have the rights to update terms of service anytime with a notice in the support server.

## 4. Contact Us
If you have any questions about this Terms of Service, please contact us at lvdat010203@gmail.com or Support Discord Server at https://discord.gg/TFvSWf9SBb.