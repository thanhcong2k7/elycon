# Privacy Policy

We assure our clients that their personal data and information will be completely secure in our databases. Please read furthur for elaboration on the information we collect.

## 1. Introduction

This Privacy Policy explains how "Phở Bò" Bot (hereinafter referred to as the "Bot") collects, uses, and protects your information when you use the Bot. By using the Bot, you agree to the collection and use of information in accordance with this policy. If you do not agree with any part of this policy, you are prohibited from using the Bot.

## 2. Infomation Collection

- **Server Infomation**
  - **Server ID**: The bot will operate on many different servers so we need to save the ID so we can identify and perform the correct function for each server.
  - **Channel ID**: Each server needs a game channel so the game can take place there.
- **User Information**
  - **User ID** & **Username**: To identify and interact with users, and we save for render leaderboard function.
  - **Message Content**: To process commands and provide responses in the game.

## 3. FAQ

- **How do we protect our client's data?** We ensure that our client's data will be safe and secure in our servers, We have taken measures to prevent data loss and overall protection of database is taken care of, We will never misuse or share your data.
- **How can you get your data wiped from our database?** You may request a data wipe in our support server tickets. Once done, we cannot revert the process or regain the database which has been lost.

## 4. Contact Us
If you have any questions about this Privacy Policy, please contact us at lvdat010203@gmail.com or Support Discord Server at https://discord.gg/TFvSWf9SBb.